-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2015 at 09:56 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `toko_bonekadb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `kd_barang` char(5) NOT NULL,
  `nm_barang` varchar(100) NOT NULL,
  `harga_modal` int(12) NOT NULL,
  `harga_jual` int(12) NOT NULL,
  `stok` int(4) NOT NULL,
  `keterangan` text NOT NULL,
  `file_gambar` varchar(100) NOT NULL,
  `kd_kategori` char(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kd_barang`, `nm_barang`, `harga_modal`, `harga_jual`, `stok`, `keterangan`, `file_gambar`, `kd_kategori`) VALUES
('B0004', 'Boneka Doraemon Xl', 60000, 71000, 3, '<p><strong>Boneka Doraemon XL</strong> dengan wajah Tersenyum sambil menjulurkan lidahnya, sehingga tampak lucu dan imut. Kedua matanya dibuat dari plastik.</p>\r\n<p>Keterangan lain:</p>\r\n<p>- Boneka terbuat dari bahan velboa yang lembut tidak berbulu<br />- Tersedia Ukuran XL 45x25cm<br />- Kualitas boneka sangat baik</p>', 'B0004.Boneka-Doraemon-XL.jpg', 'K003'),
('B0005', 'Guling Doraemon', 45000, 60000, 9, '<p><strong>Boneka Doraemon</strong> yang lucu, dapat dipakai buat teman saat bobok, bisa juga dibuat untuk hadiah ke pacar, atau juga untuk adik kecil yang imut. Ukuran L</p>', 'B0005.Guling-Doraemon-Ukuran-L.jpg', 'K003'),
('B0006', 'Boneka Doremon Baling-baling Bambu', 17000, 24000, 7, '<p>Boneka Doremon Baling-baling Bambu mini, seukuran 1,5x pensil, sangat cocok dipakai buat menambah koleksi Anda.</p>', 'B0006.Boneka-Doremon-Baling-baling-Bambu.jpg', 'K003'),
('B0007', 'Boneka Beruang (kecil) Dengan Bantal', 15000, 20000, 8, '<p>Boneka Beruang (Kecil) dengan Bantal, ukurannya kecil, 1,3 x ukuran spidol, bisa dipakai buat gantungan di kaca mobol Anda, pkoknya lucu deh</p>', 'B0007.Boneka-Beruang-(Kecil)-dengan-Bantal.jpg', 'K002'),
('B0008', 'Guling Mini Boneka Gajah', 15000, 20000, 10, '<p>Guling Mini Boneka Gajah dengan ukuran 2x besar spidol, bagus buat menambah koleksi Anda, bentuknya lucu, juga bisa dipakai buat hiasan di mobil.</p>', 'B0008.Guling-Mini-Boneka-Gajah.jpg', 'K004'),
('B0009', 'Boneka Hello Kity', 15000, 20000, 10, '<p><strong>Boneka Hello Kity</strong> ukuran mini, 1,2 x ukuran spidol, pilihan warna Merah, Biru dan Kuning, dapat dipakai buat gantungan hiasan di kamar atau di kaca mobil.</p>', 'B0009.Boneka-Hello-Kity-warna-Biru-dan-Merah.jpg', 'K005'),
('B0010', 'Hello Kity Gantungan Kunci', 7000, 10000, 10, '<p>Hello Kity Gantungan Kunci sekurang 0,8x besar spidol, cocok buat gantungan kunci anda, juga bisa dipakai buat hiasan pada kamar dan mobil.</p>', 'B0010.Hello-Kity-Gantungan-Kunci.jpg', 'K005'),
('B0011', 'Hello Kity Guling Mini', 15000, 20000, 10, '<p>Hello Kity Guling Mini yang imut, cocok buat mainan si kecil, juga bisa dipakai buat teman bobok si kecil, seukuran 2x spidol.</p>', 'B0011.Hello-Kity-Guling-Mini.jpg', 'K005'),
('B0012', 'Hello Kity Sandal', 25000, 35000, 10, '<p>Hello Kity Sandal yang lucu, bisa buat gaul saat kumpul dengan teman-teman, atau dipakai buat harian di dalam rumah dan kamar.</p>', 'B0012.Hello-Kity-Sandal.jpg', 'K005'),
('B0013', 'Hello Kity Tas', 35000, 45000, 10, '<p>Hello Kity Tas yang cocok buat kamu para cewek cewek ABG, bisa buat gaul loch.....pokoknya lucu abis</p>', 'B0013.Hello-Kity-Tas.jpg', 'K005'),
('B0003', 'Boneka Beruang Jericho', 150000, 180000, 2, '<div id="Deskripsi" class="ui-tabs-panel ui-widget-content ui-corner-bottom">\r\n<p><strong>Boneka Beruang Bear Jericho </strong>adalah boneka beruang berukuran besar, bentuknya lucu dan menggemaskan, boneka ini didesain dengan mengenakan kaos bergambar beruang dan bertuliskan "I Think..". Boneka beruang ini cocok untuk dihadiahkan untuk sang kekasih, atau untuk Anda sendiri.</p>\r\n<p>Deskripsi :</p>\r\n<p>- Bahan Snail<br />- mengenakan kaos dari bahan kain warna merah<br />- Ukuran Tinggi 75cm</p>\r\n</div>', 'B0003.Boneka Beruang Jericho - Beruang.jpg', 'K002'),
('B0001', 'Bantal Angry Birds', 55000, 65000, 5, '<p><strong>Boneka Bantal Angry Birds</strong> ini dapat Anda gunakan untuk teman bobok, sangat cocok untuk dijadikan sebagai hadian kepada sang pacar asat ulang tahun, atau hari spesial.</p>\r\n<p>Detailnya adalah :<br /> - Angry Birds yang dibuat sebagai bantal<br /> - Bentuk ramping<br /> - Mata dan patuk dari gambar bordir<br /> - Dengan bordir tulisan "Angry Birds"<br /> - Cocok sebagai alas kepala<br /> - Ukuran : 45cm x 35cm<br /> - Terbuat dari bahan rasfur yang halus dan lembut<br /> - Bantal dengan kualitas sangat baik</p>', 'B0001.Boneka-Bantal-Angry-Birds.jpg', 'K001'),
('B0002', 'Boneka Bear Love You', 80000, 99000, 2, '<div id="Deskripsi" class="ui-tabs-panel ui-widget-content ui-corner-bottom">\r\n<p><strong>Boneka Bear Love You</strong>, boneka beruang ini sangat cocok untuk diberikan sebagai hadiah kepada sang pacar atau pasangan Anda.</p>\r\n<p>Deskripsi :</p>\r\n<p>- Boneka Bear warna pink<br />- Dengan bantal hati bertuliskan "I Love You"<br />- Terbuat dari Bahan vonel<br />- Ukuran tinggi 55cm</p>\r\n</div>', 'B0002.Boneka-Bear-Love-You---Beruang.jpg', 'K002');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `kd_kategori` char(4) NOT NULL,
  `nm_kategori` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`kd_kategori`, `nm_kategori`) VALUES
('K001', 'Boneka Angry Bird'),
('K002', 'Boneka Beruang'),
('K003', 'Boneka Doraemon'),
('K004', 'Boneka Gajah'),
('K005', 'Boneka  Hello Kity'),
('K006', 'Boneka Keropi'),
('K007', 'Boneka Mario Bros'),
('K008', 'Boneka Teddy Bear'),
('K009', 'Boneka Panda'),
('K010', 'Boneka Sapi');

-- --------------------------------------------------------

--
-- Table structure for table `konfirmasi`
--

CREATE TABLE IF NOT EXISTS `konfirmasi` (
`id` int(4) NOT NULL,
  `no_pemesanan` varchar(8) NOT NULL,
  `nm_pelanggan` varchar(100) NOT NULL,
  `jumlah_transfer` int(12) NOT NULL,
  `keterangan` text NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `konfirmasi`
--

INSERT INTO `konfirmasi` (`id`, `no_pemesanan`, `nm_pelanggan`, `jumlah_transfer`, `keterangan`, `tanggal`) VALUES
(18, 'PS000003', 'april', 60000, 'cepat', '2015-12-24'),
(17, 'PS000002', 'astri w', 80756, 'cepat dikirim segera', '2015-12-24'),
(16, 'PS000001', 'arinta saskya', 80406, 'Tolong segera dikirim', '2015-12-24');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `kd_pelanggan` char(6) NOT NULL,
  `nm_pelanggan` varchar(100) NOT NULL,
  `kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_telepon` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tgl_daftar` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`kd_pelanggan`, `nm_pelanggan`, `kelamin`, `email`, `no_telepon`, `username`, `password`, `tgl_daftar`) VALUES
('P00001', 'arinta saskya', 'Perempuan', 'arintaraffa@gmail.com', '08134337000', 'arinta', '81dc9bdb52d04dc20036dbd8313ed055', '2015-12-24'),
('P00002', 'astri w', 'Perempuan', 'astrianadias@gmail.com', '08134346712', 'astri', '81dc9bdb52d04dc20036dbd8313ed055', '2015-12-24'),
('P00003', 'april', 'Perempuan', 'aprilia@gmail.com', '082146479767', 'april', '81dc9bdb52d04dc20036dbd8313ed055', '2015-12-24');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan`
--

CREATE TABLE IF NOT EXISTS `pemesanan` (
  `no_pemesanan` char(8) NOT NULL,
  `kd_pelanggan` char(6) NOT NULL,
  `tgl_pemesanan` date NOT NULL DEFAULT '0000-00-00',
  `nama_penerima` varchar(60) NOT NULL,
  `alamat_lengkap` varchar(200) NOT NULL,
  `kd_provinsi` char(3) NOT NULL,
  `kota` varchar(100) NOT NULL,
  `kode_pos` varchar(6) NOT NULL,
  `no_telepon` varchar(20) NOT NULL,
  `status_bayar` enum('Pesan','Lunas','Batal') NOT NULL DEFAULT 'Pesan'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemesanan`
--

INSERT INTO `pemesanan` (`no_pemesanan`, `kd_pelanggan`, `tgl_pemesanan`, `nama_penerima`, `alamat_lengkap`, `kd_provinsi`, `kota`, `kode_pos`, `no_telepon`, `status_bayar`) VALUES
('PS000002', 'P00002', '2015-12-24', 'astri w', 'jl.kentingan 4', 'P01', 'surakarta', '23232', '082134565765', 'Lunas'),
('PS000003', 'P00003', '2015-12-24', 'april', 'jl.slamet riyadi 22 ', 'P01', 'kartasura', '70021', '085646106406', 'Pesan'),
('PS000001', 'P00001', '2015-12-24', 'raffa', 'jl merbabu', 'P01', 'boyolali', '50021', '085646106406', 'Lunas');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan_item`
--

CREATE TABLE IF NOT EXISTS `pemesanan_item` (
`id` int(4) NOT NULL,
  `no_pemesanan` char(8) NOT NULL,
  `kd_barang` char(5) NOT NULL,
  `harga` int(12) NOT NULL,
  `jumlah` int(3) NOT NULL DEFAULT '1'
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `pemesanan_item`
--

INSERT INTO `pemesanan_item` (`id`, `no_pemesanan`, `kd_barang`, `harga`, `jumlah`) VALUES
(32, 'PS000003', 'B0005', 60000, 1),
(31, 'PS000002', 'B0001', 65000, 1),
(30, 'PS000001', 'B0001', 65000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `provinsi`
--

CREATE TABLE IF NOT EXISTS `provinsi` (
  `kd_provinsi` char(3) NOT NULL,
  `nm_provinsi` varchar(100) NOT NULL,
  `biaya_kirim` int(12) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provinsi`
--

INSERT INTO `provinsi` (`kd_provinsi`, `nm_provinsi`, `biaya_kirim`) VALUES
('P01', 'Jawa Tengah', 15000),
('P02', 'Jawa Barat', 15000),
('P03', 'Jawa Timur', 15000),
('P04', 'DKI Jakarta', 15000),
('P05', 'Yogyakarta, D.I', 15000),
('P06', 'Bali', 20000),
('P07', 'Bengkulu', 20000),
('P08', 'Banten', 20000),
('P09', 'Gorontalo', 35000),
('P10', 'Irian Jaya Barat', 35000),
('P11', 'Jambi', 25000),
('P12', 'Kalimantan Barat', 30000),
('P13', 'Kalimantan Tengah', 30000),
('P14', 'Kalimantan Timur', 30000),
('P15', 'Kalimantan Selatan', 30000),
('P16', 'Kepulauan Bangka Belitung', 30000),
('P17', 'Lampung', 20000),
('P18', 'Maluku', 25000),
('P19', 'Maluku Utara', 25000),
('P20', 'Aceh, D.I', 30000),
('P21', 'Nusa Tenggara Barat', 25000),
('P22', 'Nusa Tenggara Timur', 25000),
('P23', 'Papua', 35000),
('P24', 'Riau', 25000),
('P25', 'Kepulauan Riau', 25000),
('P26', 'Sulawesi Barat', 25000),
('P27', 'Sulawesi Tengah', 25000),
('P28', 'Sulawesi Tenggara', 25000),
('P29', 'Sulawesi Selatan', 25000),
('P30', 'Sulawesi Utara', 25000),
('P31', 'Sumatera Barat', 34000),
('P32', 'Sumatera Selatan', 35000);

-- --------------------------------------------------------

--
-- Table structure for table `tmp_keranjang`
--

CREATE TABLE IF NOT EXISTS `tmp_keranjang` (
`id` int(5) NOT NULL,
  `kd_barang` char(5) NOT NULL,
  `harga` int(12) NOT NULL,
  `jumlah` int(3) NOT NULL DEFAULT '0',
  `tanggal` date NOT NULL DEFAULT '0000-00-00',
  `kd_pelanggan` char(6) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `tmp_keranjang`
--

INSERT INTO `tmp_keranjang` (`id`, `kd_barang`, `harga`, `jumlah`, `tanggal`, `kd_pelanggan`) VALUES
(6, '1', 0, 0, '0000-00-00', ''),
(33, 'B0001', 65000, 1, '2015-12-24', 'P00006'),
(34, 'B0002', 99000, 1, '2015-12-24', 'P00006'),
(36, 'B0001', 65000, 1, '2015-12-24', 'P00008'),
(45, 'B0007', 20000, 1, '2015-12-24', 'P00002'),
(44, 'B0003', 180000, 1, '2015-12-24', 'P00002');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
 ADD PRIMARY KEY (`kd_barang`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
 ADD PRIMARY KEY (`kd_kategori`);

--
-- Indexes for table `konfirmasi`
--
ALTER TABLE `konfirmasi`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
 ADD PRIMARY KEY (`kd_pelanggan`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
 ADD PRIMARY KEY (`no_pemesanan`);

--
-- Indexes for table `pemesanan_item`
--
ALTER TABLE `pemesanan_item`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provinsi`
--
ALTER TABLE `provinsi`
 ADD PRIMARY KEY (`kd_provinsi`);

--
-- Indexes for table `tmp_keranjang`
--
ALTER TABLE `tmp_keranjang`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `konfirmasi`
--
ALTER TABLE `konfirmasi`
MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `pemesanan_item`
--
ALTER TABLE `pemesanan_item`
MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `tmp_keranjang`
--
ALTER TABLE `tmp_keranjang`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
