<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Panduan</title>
</head>
<body>
<div class="rata_kiri">
<strong>PANDUAN BELANJA</strong>
<ol>
  <li>Pertama, silahkan Anda mendaftar sebagai member pelanggan di web ini. Caranya, klik <a href="?open=Pelanggan-Baru" target="_self"><strong>Pendaftaran Baru</strong></a> di bawah kotak <strong>LOGIN</strong>. </li>
  <li>Lengkapi data-data form Pendaftaran, juga Username dan Password harus Anda ingat.</li>
  <li>Login menggunakan Username dan Password yang sudah Anda miliki saat mendaftar tadi.</li>
  <li>Lakukan pemesanan barang dengan mengklik menu <strong>Beli</strong> yang ada di setiap Barang, dan barang yang sudah dipilih akan masuk ke <a href="?open=Keranjang-Belanja" target="_blank"><strong>Keranjang Belanja</strong></a>, dan Anda dapat mengubah jumlah barangnya, atau juga bisa dihapus jika memang mau dibatalkan.</li>
  <li>Jika sudah selesai memilih barang, klik menu/tombol <strong><a href="?open=Transaksi-Lanjut" target="_self">Lanjutkan</a></strong>, lalu Anda akan dibawa ke halaman konfirmasi (form) kemana barang akan dikirim. Silahkan isikan data alamat lenngkap tempat pengiriman barang. Meskipun Anda sudah memiliki data pribadi, akan tetapi pada halaman ini tetap harus Anda isi, karna datanya bisa juga dengan alamat orang lain sebagai tujuan pengiriman. </li>
  <li>Setelah pemesanan selesai, barang akan masuk ke daftar <strong>Transaksi Pesan</strong>.</li>
  <li>Anda dapat melakukan pembayaran dengan cara transfer ke rekening Pemilik Toko.</li>
  <li>Setelah Anda melakukan pembayaran, Anda dapat melakukan <a href="?open=Konfirmasi" target="_blank"><strong>Konfirmasi Pembayaran</strong></a>.</li>
  <li>Konfirmasi pembayaran akan dibaca oleh Admin, jika memang sudah benar (uang transferan Anda sudah masuk ke rekening Kami), maka status pemesanan barang Anda akan diset dari status <strong>Pesan</strong> menjadi <strong>Lunas</strong>, dan pemilik toko siap mengirim barang ke alamat Anda.</li>
  <li>Setelah barang dikirim, pemilik toko dapat mengkonfirmasi ke pada Anda, nomor resi pengiriman yang didapat dari POS atau agen paket yang digunakan.</li>
  <li>Anda menerima barangnya. </li> 
</ol>
</div>
</body>
</html>
