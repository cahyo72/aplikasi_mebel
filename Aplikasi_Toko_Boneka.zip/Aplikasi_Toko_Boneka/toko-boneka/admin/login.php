<center><form name="logForm" method="post" action="?open=Login-Validasi">
  <table class="table-list" width="500" border="0" cellpadding="2" cellspacing="1" bgcolor="#999999">
    <tr>
      <td width="106" rowspan="4" align="center" bgcolor="#CCCCCC"><img src="../images/login-key.png" width="116" height="75" /></td>
      <th colspan="2" bgcolor="#999999"><strong>LOGIN ADMIN</strong></td>      
    </tr>
    <tr>
      <td width="117" bgcolor="#FFFFFF"><strong>Username</strong></td>
      <td width="263" bgcolor="#FFFFFF"><strong>: 
        <input name="txtUsername" type="text" size="30" maxlength="20" />
      </strong></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF"><strong>Password</strong></td>
      <td bgcolor="#FFFFFF"><strong>: 
        <input name="txtPassword" type="password" size="30" maxlength="20" />
      </strong></td>
    </tr>
    
    <tr>
      <td bgcolor="#FFFFFF">&nbsp;</td>
      <td bgcolor="#FFFFFF"><input type="submit" name="btnLogin" value=" Login " /></td>
    </tr>
  </table>
</form></center>
