<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home</title>
</head>
<body>
<table width="100%" border="0" cellspacing="1" cellpadding="3">
  <tr>
    <td align="center"><img src="images/home.png" width="600" height="200"></td>
  </tr>
</table>
<?php include "barang.php"; ?>
</body>
</html>
