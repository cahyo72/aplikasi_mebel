<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<div align="left">
<p>TOKO BONEKA LUNANIA </p>
<p>Toko Boneka Online Lengkap</p>
<p>...............informasi diketik sendiri di info_profil.php</p>
<p>&nbsp;</p>
<ul>
<ul>
  <li>Email&nbsp;&nbsp; : boneka_lunania@yahoo.com  </li>
  <li>Pin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : 34A63FFB</li>
  <li>Tlpn&nbsp;&nbsp;&nbsp;&nbsp; : 733365</li>
  <li>Hp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : 0819011111111 </li>
</ul>
</body>
</html>
