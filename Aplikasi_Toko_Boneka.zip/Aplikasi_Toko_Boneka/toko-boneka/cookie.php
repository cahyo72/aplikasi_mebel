<?php
if(isset($_COOKIE['KunjunganTerakhir'])) {
$visit = $_COOKIE['KunjunganTerakhir'];
echo "Kunjungan Anda terakhir pada - ". $visit;
}
else
echo "Anda sudah lebih dari 2 jam tidak mengunjungi web ini";
?>
